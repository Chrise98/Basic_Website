A code about a site that has been upgraded.
